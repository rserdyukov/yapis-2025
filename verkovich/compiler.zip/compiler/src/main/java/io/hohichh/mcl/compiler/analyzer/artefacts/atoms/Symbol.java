package io.hohichh.mcl.compiler.analyzer.artefacts.atoms;

public interface Symbol {
    String getName();
    MclType getType();
}
